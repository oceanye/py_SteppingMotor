# Math-only archive initializer; NOT the production package initializer.
