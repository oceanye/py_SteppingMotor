# 三足腿—高杆避让：独立研究资料包

2026-09-24；生产源码基线 57dc02bd1a0c40d41c7845e8940a3d7d9f5b4de3。

主线负责人先阅读 docs/HANDOFF_2026-09-24_GAIT_RESEARCH_BRANCH.md。
本分支交付控制逻辑分析及研究证据，未修改生产控制代码，未部署候选参数。

先阅读 docs/EXTERNAL_BRIEF_2026-09-24_GAIT_CLEARANCE_OPTIMIZATION.md，
再阅读 docs/RESEARCH_2026-09-24_GAIT_SPIN_ORBIT_AVOIDANCE.md。
CSV、JSON及五组SVG/PNG图均在 docs/assets/gait_avoidance_2026-09-24/。

Python 3.10+，在解压后的根目录运行：

    python -B scripts/research_gait_clearance.py

仅需标准库。重生成CSV/JSON/SVG，不自动刷新PNG；PNG是随包提供的原始快照。
没有电机连接、串口、GUI、配置写入或固件刷写。请不要将此包当作完整应用。
几何模块 gait_avoidance.py、gait_planner.py 原样复制。
仅本ZIP的 motor_control/__init__.py 使用数学研究专用的空初始化文件，
避免加载完整应用依赖；工作区生产初始化文件没有修改。
其他控制/GUI/固件源码和测试为审阅参考，不保证可在裁剪包中独立运行。

重点问题：分别优化LOW/HIGH全程最小间隙；逐姿态最大值不等于安全路径。
当前n=18未改动；n=19.6只是有限族离线候选，未证明全局最优，未部署。
图中距离为腿中心线到高杆轴线的距离/R，尚未扣除实体厚度和误差。
现场标定参数缺失，不可凭此批准实机运行。

MANIFEST.sha256列出所有其他包内文件的SHA-256。
文档中的资料包下载链接指向本ZIP自身，解压目录内不会重复嵌套该ZIP。
不包含.git、虚拟环境、机器配置、账户凭据或整套运行环境。
